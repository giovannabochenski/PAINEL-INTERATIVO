criaCartao(
    'Matue',
    'Qual foi o ultimo album do matue',
    '333'
)

criaCartao(
    'Matue',
    'Quem é Matue',
    'Matuê é um rapper e cantor brasileiro, bastante conhecido na cena do trap e rap nacional'
)

criaCartao(
    'Tue',
    'Qual a melhor musica do matue',
    'Estou em dúvida'
)

criaCartao(
    '30',
    'Oque é  a 30',
    'A 30 é um dos álbuns mais conhecidos de Matuê, lançado em 2020💜💜💜'
)
